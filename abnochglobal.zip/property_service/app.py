
from flask import Flask, jsonify, render_template

app = Flask(__name__)

properties = [
    {
        "id": 1,
        "title": "Luxury 4 Bedroom Duplex",
        "location": "Lekki, Lagos",
        "price": "₦120,000,000",
        "image": "https://picsum.photos/600/400?random=1"
    },
    {
        "id": 2,
        "title": "Modern 3 Bedroom Apartment",
        "location": "Abuja",
        "price": "₦85,000,000",
        "image": "https://picsum.photos/600/400?random=2"
    },
    {
        "id": 3,
        "title": "Commercial Office Space",
        "location": "Victoria Island, Lagos",
        "price": "₦250,000,000",
        "image": "https://picsum.photos/600/400?random=3"
    }
]

@app.route("/")
def home():
    return render_template("index.html", properties=properties)

@app.route("/api/properties")
def get_properties():
    return jsonify(properties)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
